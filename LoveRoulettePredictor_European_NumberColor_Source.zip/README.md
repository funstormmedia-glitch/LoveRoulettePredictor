# Love Roulette Predictor (European Roulette 0–36)

## Included
- Android Studio project using a simple Android WebView shell.
- Number + color estimate based on a transparent frequency baseline.
- Spin history stored locally, exact-number and color hit-rate tracking.
- European roulette theoretical probabilities.

## Important limitation
This project cannot reliably predict random roulette outcomes. Its frequency-based candidate list is an illustrative statistic, not a winning system.

## Build the APK
This ZIP is source code, not a compiled APK. To build:
1. Install Android Studio on a computer.
2. Open this project folder in Android Studio.
3. Allow Gradle sync to finish (internet may be needed to download Android Gradle Plugin).
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Find the generated file under `app/build/outputs/apk/debug/app-debug.apk`.

The current execution environment did not have Android SDK / Gradle installed, so a compiled APK could not be verified or produced here.
